#ifndef HOTEDGE_H
#define  HOTEDGE_H

/* Each edge of the screen has a unique edge number >= 0 */
enum
{
  HOT_EDGE_TOP, HOT_EDGE_RIGHT,
  HOT_EDGE_BOTTOM, HOT_EDGE_LEFT,
  HOT_EDGE_LAST
};

extern int HotEdgeEnabled;

void HotEdgeInit(void);
int HotEdgeActivate(int n, int module);
void HotEdgeConfigure(void);
void HotEdgeEnter(PanFrame *panframe);


#endif /* HOTEDGE_H */
