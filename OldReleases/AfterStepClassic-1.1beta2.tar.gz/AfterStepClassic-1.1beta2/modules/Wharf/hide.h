/* hide.h */
/* Stuff exported from hide.c */

extern void HideInit(void);
extern void HideSetMainGeometry(int x, int y, int w, int h);
extern void HideEnable(int enable);
extern void HidePopUp(void);
extern int HideOnLeaveNotify(Window w, int x, int y);
extern void HidePopDown(void);
